/* ανάγνωση μονοψήφιου ακεραίου σύμφωνα με την έκφραση
   number={whitechar}digit{digit|char|whitechar}    */

#include <stdio.h>

int main(int argc, char *argv[]) {

  char c;
  int v;

  do {
    c = getchar();
  } while ((c == ' ') || (c == '\n') || (c == '\t'));
  
  v = 0; 
  v = v + c-'0';
  
  do {
    c = getchar();
  } while (c != '\n');

  printf("%d\n", v);
}