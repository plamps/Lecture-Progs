#include <stdio.h>

int main(void) {

int i;

	i = 11;
	while (--i > 0);        /*** ΛΑΘΟΣ ***/
	  printf("T minus %d and counting\n", i);
      
}