#include <stdio.h>

int main(void) {
  int a=1, b=2;
  
  printf("a is %d, b is %d and a+b is %d\n", a , b , a+b );
}
